/////////////////////////////////////////////////////////////////////////////
// Message.h - Constructing and interpreting messages.                     //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "Message.h"

#include <atomic>
#include <sstream>
#include <utility>
#include <cstdlib>
#include <iostream>

// The default constructor of Message class
Message::Message()
	: type((TYPE)(EXIT + 1)), srcPort(0), dstPort(0), contentLen(0), chunkCount(0), chunkNo(0)
{
}

// For generating unique message id
static std::atomic_int id;

// Split a string into substrings
static
std::vector<std::string> split(std::string const & src, char delim) {
	std::vector<std::string> retValue;
	std::stringstream ss(src);
	std::string item;
	while (std::getline(ss, item, delim)) {
		retValue.push_back(item);
	}
	return retValue;
}

// Parse a message string into a Message object
Message::Message(std::string const & src) {
	auto items = split(src, '\n');
	type = (TYPE)(items[0][0] - 0x30);
	srcAddr = std::move(items[1]);
	srcPort = (unsigned int)std::stoul(items[2]);
	dstAddr = std::move(items[3]);
	dstPort = (unsigned int)std::stoul(items[4]);
	fileName = std::move(items[5]);
	contentLen = (unsigned int)std::stoul(items[6]);
	chunkCount = (unsigned int)std::stoul(items[7]);
	chunkNo = (unsigned int)std::stoul(items[8]);
}

// Move constructor
Message::Message(Message && src) {
	*this = std::move(src);
}

// Move assignment operator
Message & Message::operator=(Message && src) {
	std::swap(type, src.type);
	std::swap(srcAddr, src.srcAddr);
	std::swap(srcPort, src.srcPort);
	std::swap(dstAddr, src.dstAddr);
	std::swap(dstPort, src.dstPort);
	std::swap(fileName, src.fileName);
	std::swap(contentLen, src.contentLen);
	std::swap(chunkCount, src.chunkCount);
	std::swap(chunkNo, src.chunkNo);
	
	return *this;
}

// Build a text message
Message Message::buildTextMsg(
	std::string const & srcAddr,
	unsigned int srcPort,
	std::string const & dstAddr,
	unsigned int dstPort,
	std::string const & content
) {
	Message retValue;

	retValue.type = TEXT_MSG;
	retValue.srcAddr = srcAddr;
	retValue.srcPort = srcPort;
	retValue.dstAddr = dstAddr;
	retValue.dstPort = dstPort;
	retValue.fileName = std::to_string(id.fetch_add(1));
	retValue.contentLen = content.size() + 1;
	retValue.chunkCount = 1;
	retValue.chunkNo = 0;

	return retValue;
}

// Build a file uploading message
Message Message::buildFileMsg(
	std::string const & srcAddr,
	unsigned int srcPort,
	std::string const & dstAddr,
	unsigned int dstPort,
	std::string const & fileName,
	size_t chunkSize,
	unsigned int chunkCount,
	unsigned int chunkNo
) {
	Message retValue;

	retValue.type = UPLOAD_FILE;
	retValue.srcAddr = srcAddr;
	retValue.srcPort = srcPort;
	retValue.dstAddr = dstAddr;
	retValue.dstPort = dstPort;
	retValue.fileName = fileName;
	retValue.contentLen = chunkSize;
	retValue.chunkCount = chunkCount;
	retValue.chunkNo = chunkNo;

	return retValue;
}

// Build a file download message
Message Message::buildDownload(
	std::string const & srcAddr,
	unsigned int srcPort,
	std::string const & dstAddr,
	unsigned int dstPort,
	std::string const & fileName,
	size_t contentLen
) {
	Message retValue;

	retValue.type = DOWNLOAD_FILE;
	retValue.srcAddr = srcAddr;
	retValue.srcPort = srcPort;
	retValue.dstAddr = dstAddr;
	retValue.dstPort = dstPort;
	retValue.fileName = fileName;
	retValue.contentLen = contentLen;
	retValue.chunkCount = 1;
	retValue.chunkNo = 0;

	return retValue;
}

// Build a search message
Message Message::buildSearch(
	std::string const & srcAddr,
	unsigned int srcPort,
	std::string const & dstAddr,
	unsigned int dstPort,
	std::string const & path
) {
	Message retValue;

	retValue.type = SEARCH_FILE;
	retValue.srcAddr = srcAddr;
	retValue.srcPort = srcPort;
	retValue.dstAddr = dstAddr;
	retValue.dstPort = dstPort;
	retValue.fileName = path;
	retValue.contentLen = 0;
	retValue.chunkCount = 1;
	retValue.chunkNo = 0;

	return retValue;
}

// Convert a message into its receipt
void Message::turnToReceipt(bool isNegative) {
	if (type == TEXT_MSG) {
		type = TEXT_RECEIPT;
	} else if (type == UPLOAD_FILE) {
		type = FILE_RECEIPT;
	} else if (type == SEARCH_FILE) {
		type = SEARCH_RECEIPT;
	} /* else { // DISCONNECT or DOWNLOAD_FILE
	    type = type;
	} */
	std::swap(srcAddr, dstAddr);
	std::swap(srcPort, dstPort);
	//fileName = fileName;
	contentLen = 0;
	//chunkCount = chunkCount;
	if (isNegative) {
		chunkNo = chunkCount + chunkNo + 1;
	} else {
		chunkNo = chunkCount;
	}
}

// Build a disconnect message
Message Message::buildDisconnect(
	std::string const & srcAddr,
	unsigned int srcPort,
	std::string const & dstAddr,
	unsigned int dstPort
) {
	Message retValue;

	retValue.type = DISCONNECT;
	retValue.srcAddr = srcAddr;
	retValue.srcPort = srcPort;
	retValue.dstAddr = dstAddr;
	retValue.dstPort = dstPort;
	retValue.fileName = "DISCONNECT";
	retValue.contentLen = 0;
	retValue.chunkCount = 1;
	retValue.chunkNo = 0;

	return retValue;
}

// Build an exit message
Message Message::buildExit(
	std::string const & localAddr,
	unsigned int localPort
) {
	Message retValue;

	retValue.type = EXIT;
	retValue.srcAddr = localAddr;
	retValue.srcPort = localPort;
	retValue.dstAddr = localAddr;
	retValue.dstPort = localPort;
	retValue.fileName = "EXIT";
	retValue.contentLen = 0;
	retValue.chunkCount = 1;
	retValue.chunkNo = 0;

	return retValue;
}

// Convert a Message object into a string
std::string Message::toString() const {
	std::string retValue;

	retValue += std::to_string(type);
	retValue += '\n';
	retValue += srcAddr;
	retValue += '\n';
	retValue += std::to_string(srcPort);
	retValue += '\n';
	retValue += dstAddr;
	retValue += '\n';
	retValue += std::to_string(dstPort);
	retValue += '\n';
	retValue += fileName;
	retValue += '\n';
	retValue += std::to_string(contentLen);
	retValue += '\n';
	retValue += std::to_string(chunkCount);
	retValue += '\n';
	retValue += std::to_string(chunkNo);

	return retValue;
}

// Get message's type
Message::TYPE Message::getType() const {
	return type;
}

// Get the address of the sending peer of the message
std::string const & Message::getSrcAddr() const {
	return srcAddr;
}

// Set the address of the sending peer of the message
void Message::setSrcAddr(std::string && addr) {
	srcAddr = std::move(addr);
}

// Get the receiving port of the sending peer of the message
unsigned int Message::getSrcPort() const {
	return srcPort;
}

// Get the address of the receiving peer of the message
std::string const & Message::getDstAddr() const {
	return dstAddr;
}

// Get the port of the receiving peer of the message
unsigned int Message::getDstPort() const {
	return dstPort;
}

// Get the file name or message id of the message
std::string const & Message::getFileName() const {
	return fileName;
}

// Get the body length of a message
size_t Message::getContentLen() const {
	return contentLen;
}

// Set the body length of a message
void Message::setContentLen(size_t contentLen_) {
	contentLen = contentLen_;
}

// Get the part count of a text message or a file message
unsigned int Message::getChunkCount() const {
	return chunkCount;
}

// Get the chunk number of a text message or a file message
unsigned int Message::getChunkNo() const {
	return chunkNo;
}

// Check is the message illegal
bool Message::isIllegal() const {
	if (type < TEXT_MSG || type > EXIT) {
		return true;
	}
	if (srcAddr.empty() || srcPort == 0 || dstAddr.empty() || dstPort == 0) {
		return true;
	}
	if (fileName.empty()) {
		return true;
	}
	if (chunkCount == 0) {
		return true;
	}
	return false;
}

// Check is the message a receipt
bool Message::isReceipt() const {
	return type == TEXT_RECEIPT ||
			type == FILE_RECEIPT ||
			type == SEARCH_RECEIPT ||
			(chunkCount != 0 && chunkNo >= chunkCount);
}

// Check is the message is a negative receipt (for file messages)
bool Message::isNegative(size_t * pChunkNo) const {
	if (chunkNo > chunkCount) {
		if (pChunkNo != nullptr) {
			*pChunkNo = chunkNo - chunkCount - 1;
		}
		return true;
	}
	return false;
}

//----< test buffer handling >-----------------------------------------------
#ifdef TEST_MESSAGE
int main(){
	Message test("send haha:xixi");
	std::cout << test.findCommand() << std::endl;
	std::cout << test.findSrcAddr().first << std::endl;
	std::cout << test.findSrcAddr().second << std::endl;
	if (test.hasBody() == 0){ return 0; }
	size_t t = test.hasBody();
	std::cout << t << std::endl;
	std::cout << test.findBody(t) << std::endl;

}
#endif