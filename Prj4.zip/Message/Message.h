#ifndef MESSAGE_H
#define MESSAGE_H
/////////////////////////////////////////////////////////////////////////////
// Message.h - Constructing and interpreting messages.                     //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Message receives a string to create a Message object. Or create an illegal
* Message object to hang up msg processing.
* - build disconnect msg
* - build exit msg
* - build file msg
* - build text msg
* - build receipt msg
* - get command from msg
* - get all attributes from msg
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv project3_communication.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 13 Apr 2015
*   first release
*/
#include <memory>
#include <string>
#include <vector>

class Message {
public:
	enum TYPE {
		TEXT_MSG,
		TEXT_RECEIPT,
		UPLOAD_FILE,
		FILE_RECEIPT,
		DOWNLOAD_FILE,
		SEARCH_FILE,
		SEARCH_RECEIPT,
		DISCONNECT,
		EXIT
	};

	Message();
	Message(std::string const &);
	Message(Message const &) = delete;
	Message(Message &&);
	Message & operator=(Message const &) = delete;
	Message & operator=(Message &&);

	static
	Message buildTextMsg(
		std::string const & srcAddr,
		unsigned int srcPort,
		std::string const & dstAddr,
		unsigned int dstPort,
		std::string const & content
	);

	static
	Message buildFileMsg(
		std::string const & srcAddr,
		unsigned int srcPort,
		std::string const & dstAddr,
		unsigned int dstPort,
		std::string const & fileName,
		size_t chunkSize,
		unsigned int chunkCount,
		unsigned int chunkNo
	);

	static
	Message buildDisconnect(
		std::string const & srcAddr,
		unsigned int srcPort,
		std::string const & dstAddr,
		unsigned int dstPort
	);

	static
	Message buildDownload(
		std::string const & srcAddr,
		unsigned int srcPort,
		std::string const & dstAddr,
		unsigned int dstPort,
		std::string const & fileName,
		size_t contentLen
	);

	static
	Message buildSearch(
		std::string const & srcAddr,
		unsigned int srcPort,
		std::string const & dstAddr,
		unsigned int dstPort,
		std::string const & path
	);

	static Message buildExit(
		std::string const & srcAddr,
		unsigned int srcPort
	);

	void turnToReceipt(bool isNegative = false);

	std::string toString() const;

	TYPE getType() const;

	std::string const & getSrcAddr() const;

	void setSrcAddr(std::string &&);

	unsigned int getSrcPort() const;

	std::string const & getDstAddr() const;

	unsigned int getDstPort() const;

	std::string const & getFileName() const;

	size_t getContentLen() const;

	void setContentLen(size_t contentLen);

	unsigned int getChunkCount() const;

	unsigned int getChunkNo() const;

	bool isIllegal() const;

	bool isReceipt() const;

	bool isNegative(size_t * pChunkNo) const;

private:

	TYPE type;
	std::string srcAddr;
	unsigned int srcPort;
	std::string dstAddr;
	unsigned int dstPort;
	std::string fileName;
	size_t contentLen;
	unsigned int chunkCount;
	unsigned int chunkNo;
};

#endif
