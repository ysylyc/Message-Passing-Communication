#ifndef _FILESEARCH_H_
#define _FILESEARCH_H_
/////////////////////////////////////////////////////////////////////////////
// FileSearch.h - search file name or text in files                        //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* search file or text in file as given directory and patterns
*
* Public Interface:
* -------------------
* getFiles(
*		std::string const & rootDir,
*		std::string const & subDir,
*		std::string const & filePattern,
*		std::string const & textPattern
*	);
*
* Required Files:
* ---------------
* FileSearch.h, FileSearch.cpp
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv Project4.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 27 APR 2015
*   first release
*/
#include <string>
#include <vector>

class FileSearch {
public:

	static
	std::vector<std::string> getFiles(
		std::string const & rootDir,
		std::string const & subDir,
		std::string const & filePattern,
		std::string const & textPattern
	);
};

#endif//_FILESEARCH_H_
