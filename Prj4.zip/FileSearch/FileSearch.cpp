/////////////////////////////////////////////////////////////////////////////
// FileSearch.h - search file name or text in files                        //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "FileSearch.h"

#include "../FileSystem/FileSystem.h"

#include <regex>
// get files recursively
void recursiveGetFiles(
	std::vector<std::string> & vec,
	std::string const & rootDir,
	std::string const & appendDir,
	std::string const & pattern
) {
	for (auto const & subDir :
		FileSystem::Directory::getDirectories(rootDir + appendDir, "*")
	) {
		if (subDir != "." && subDir != "..") {
			recursiveGetFiles(vec, rootDir, appendDir + "\\" + subDir, pattern);
		}
	}
	for (auto const & fileName :
		FileSystem::Directory::getFiles(
			rootDir + appendDir,
			pattern.empty() ? "*" : pattern
		)
	) {
		vec.push_back(appendDir + "\\" + fileName);
	}
}
// get files
std::vector<std::string> FileSearch::getFiles(
	std::string const & rootDir,
	std::string const & subDir,
	std::string const & filePattern,
	std::string const & textPattern
) {
	std::vector<std::string> files, retValue;

	recursiveGetFiles(files, rootDir, subDir, filePattern);

	if (textPattern.empty()) {
		retValue = std::move(files);
		return retValue;
	}
	std::regex textRegex(textPattern, std::regex::ECMAScript | std::regex::nosubs);
	for (auto & item : files) {
		FileSystem::File file(rootDir + item);
		file.open(FileSystem::File::in, false);
		auto content = file.readAll(true);
		if (std::regex_search(content, textRegex)) {
			retValue.emplace_back(std::move(item));
		}
	}
	return retValue;
}

//----< test buffer handling >-----------------------------------------------
#ifdef TEST_FILESEARCH
int main(){
	auto test = getFiles(".","./cpp","*","test");
	std::cout << test[0];
}
#endif