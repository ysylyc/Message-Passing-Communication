/////////////////////////////////////////////////////////////////////////
// AppHelpers.cpp - I/O and Conversion helpers                         //
// ver 2.0                                                             //
//---------------------------------------------------------------------//
// Jim Fawcett (c) copyright 2015                                      //
// All rights granted provided this copyright notice is retained       //
// Siyuan Ye, siye@syr.edu                                             //
//---------------------------------------------------------------------//
// Application: OOD Projects #3, #4                                    //
// Platform:    Visual Studio 2013, Dell 2720, Win 8.1 pro             //
/////////////////////////////////////////////////////////////////////////

#include "AppHelpers.h"
#include <string>
#include <iostream>

//using namespace ApplicationHelpers;

bool ApplicationHelpers::Verbose::showState_ = false;
const bool ApplicationHelpers::always = true;

std::mutex ioMtx;

void ApplicationHelpers::title(const std::string& msg, char underline)
{
	std::lock_guard<std::mutex> lock(ioMtx);
	std::cout << "  " << msg << std::endl << "  " << std::string(msg.size() + 2, underline) << std::endl;
}

void ApplicationHelpers::putLine(const std::string& msg) 
{
	std::lock_guard<std::mutex> lock(ioMtx);
	std::cout << msg << std::endl;
}

ApplicationHelpers::Verbose::Verbose(bool showState) 
{ 
	showState_ = showState; 
	if (showState)
		putLine("  Verbose mode turned on");
}

void ApplicationHelpers::Verbose::show(const std::string& msg, bool always)
{
	std::lock_guard<std::mutex> lock(ioMtx);
	if (always == true || showState_ == true)
	{
		std::string temp = "  " + std::string(msg) + "\n";
		std::cout << temp;
		std::cout.flush();
	}
}

#ifdef TEST_APPLICATIONHELPERS

int main()
{

}

#endif
