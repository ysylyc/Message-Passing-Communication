/////////////////////////////////////////////////////////////////////////////
// CLIWrapper.h - wrap native wrapper of peer class                        //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "CLIWrapper.h"

#include "../Peer/PeerWrapper.h"

#include <msclr\gcroot.h>

#include <functional>
// convert native string to managed string
String ^ nativeStrToManagedStr(std::string const & string) {
	return gcnew String(string.c_str());
}
// convert managed string to native string
std::string managedStrToNativeStr(String ^ string) {
	auto ptr = (char const *)(
		Runtime::InteropServices::Marshal::StringToHGlobalAnsi(string).
		ToPointer()
		);
	std::string retValue(ptr);
	Runtime::InteropServices::Marshal::FreeHGlobal(IntPtr((void *)(ptr)));
	return retValue;
}
// convert vector to list
List<String ^> ^ nativeVectorToManagedList(std::vector<std::string> const & vec) {
	List<String ^> ^ list = gcnew List<String ^>();
	for (auto const & item : vec) {
		list->Add(nativeStrToManagedStr(item));
	}
	return list;
}
// ouput string to console
void nativeWriteString(
	msclr::gcroot<CliWrapper::Peer ^> cliPeer,
	std::string const & string
	) {
	cliPeer->writeString(nativeStrToManagedStr(string));
}
// set categories in native code
void nativeSetCategories(
	msclr::gcroot<CliWrapper::Peer ^> cliPeer,
	std::vector<std::string> const & vecCats
	) {
	cliPeer->setCategories(nativeVectorToManagedList(vecCats));
}
// set file list in native code
void nativeSetFileList(
	msclr::gcroot<CliWrapper::Peer ^> cliPeer,
	std::vector<std::string> const & vecFiles
	) {
	cliPeer->setFileList(nativeVectorToManagedList(vecFiles));
}

namespace CliWrapper {
	// Constructor
	Peer::Peer(
		String ^ peerName,
		UInt32 port,
		DeleWriteString ^ writeString_,
		DeleProcessList ^ setCategories_,
		DeleProcessList ^ setFileList_
		) {
		writeString = writeString_;
		setCategories = setCategories_;
		setFileList = setFileList_;
		nativeWrapper = new PeerWrapper(
			managedStrToNativeStr(peerName),
			port,
			std::bind(
			nativeWriteString,
			msclr::gcroot<CliWrapper::Peer ^>(this),
			std::placeholders::_1
			),
			std::bind(
			nativeSetCategories,
			msclr::gcroot<CliWrapper::Peer ^>(this),
			std::placeholders::_1
			),
			std::bind(
			nativeSetFileList,
			msclr::gcroot<CliWrapper::Peer ^>(this),
			std::placeholders::_1
			)
			);
	}
	// Destructor
	Peer::~Peer() {
		delete nativeWrapper;
	}
	// Send a text message to a peer
	void Peer::sendMsgTo(String ^ remoteAddr, UInt32 remotePort, String ^ message) {
		nativeWrapper->sendMsgTo(
			managedStrToNativeStr(remoteAddr),
			remotePort,
			managedStrToNativeStr(message)
			);
	}
	// Send a file to a peer
	void Peer::sendFileTo(
		String ^ remoteAddr,
		UInt32 remotePort,
		String ^ fileName,
		String ^ remotePath
		) {
		nativeWrapper->sendFileTo(
			managedStrToNativeStr(remoteAddr),
			remotePort,
			managedStrToNativeStr(fileName),
			managedStrToNativeStr(remotePath)
			);
	}
	// download a file from a peer
	void Peer::downloadFileFrom(
		String ^ remoteAddr,
		UInt32 remotePort,
		String ^ fileName,
		String ^ localPath
		) {
		nativeWrapper->downloadFileFrom(
			managedStrToNativeStr(remoteAddr),
			remotePort,
			managedStrToNativeStr(fileName),
			managedStrToNativeStr(localPath)
			);
	}
	// get categories from remote peer
	void Peer::getDirectories(String ^ remoteAddr, UInt32 remotePort) {
		nativeWrapper->getDirectories(managedStrToNativeStr(remoteAddr), remotePort);
	}
	// search file
	void Peer::searchFileAt(
		String ^ remoteAddr,
		UInt32 remotePort,
		String ^ path,
		String ^ filePattern,
		String ^ textpattern
		) {
		nativeWrapper->searchFileAt(
			managedStrToNativeStr(remoteAddr),
			remotePort,
			managedStrToNativeStr(path),
			managedStrToNativeStr(filePattern),
			managedStrToNativeStr(textpattern)
			);
	}
	// Disconnect from a peer
	void Peer::disconnect(String ^ remoteAddr, UInt32 remotePort) {
		nativeWrapper->disconnect(managedStrToNativeStr(remoteAddr), remotePort);
	}
	// Shutdown the peer
	void Peer::shutdown() {
		nativeWrapper->shutdown();
	}
	// Constructor for socket system
	SocketSystem::SocketSystem() {
		nativeWrapper = new SocketSystemWrapper();
	}
	// Destructor for socket system
	SocketSystem::~SocketSystem() {
		delete nativeWrapper;
	}

}

//----< test buffer handling >-----------------------------------------------
#ifdef TEST_CLIWRAPPER
int main(){
	SocketSystem::SocketSystem();
	string^ haha = nativeStrToManagedStr("test");
	Console.writeline(haha);
}
#endif
