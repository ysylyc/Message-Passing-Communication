#ifndef _CLIWRAPPER_H_
#define _CLIWRAPPER_H_
/////////////////////////////////////////////////////////////////////////////
// CLIWrapper.h - wrap native wrapper of peer class                        //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Wrap native wrapper of peer class in project3 for compatible with C++/CLI code.
*
* Required Files:
* ---------------
* CLIWrapper.h, CLIWrapper.cpp, PeerWrapper.h, PeerWrapper.cpp
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv Project4.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 27 APR 2015
*   first release
*/
using namespace System;
using namespace System::Text;
using namespace System::Collections::Generic;

#include <string>
#include <vector>

class PeerWrapper;
class SocketSystemWrapper;

namespace CliWrapper {

public ref class Peer {
public:
	delegate void DeleWriteString(String ^ string);
	delegate void DeleProcessList(List<String ^> ^ strList);

	Peer(
		String ^ peerName,
		UInt32 port,
		DeleWriteString ^ writeString,
		DeleProcessList ^ setCategories,
		DeleProcessList ^ setFileList
	);
	~Peer();

	void sendMsgTo(String ^, UInt32, String ^);
	void sendFileTo(String ^, UInt32, String ^, String ^);
	void downloadFileFrom(String ^, UInt32, String ^, String ^);
	void getDirectories(String ^, UInt32);
	void searchFileAt(String ^, UInt32, String ^, String ^, String ^);

	void disconnect(String ^, UInt32);
	void shutdown();

internal:
	DeleWriteString ^ writeString;
	DeleProcessList ^ setCategories;
	DeleProcessList ^ setFileList;

private:
	PeerWrapper * nativeWrapper;
};

public ref class SocketSystem {
public:
	SocketSystem();
	~SocketSystem();

private:
	SocketSystemWrapper * nativeWrapper;
};

}

#endif//_CLIWRAPPER_H_
