﻿/////////////////////////////////////////////////////////////////////////////
// App.cs - C# implementation of WPF Application for CSE 687 Project #4    //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Start a C# WPF application. 
*
* Required Files:
* ---------------
* CLIWrapper.h, CLIWrapper.cpp
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv Project4.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 27 APR 2015
*   first release
*/
namespace WPFWindow {

    public class App : System.Windows.Application, System.IDisposable {

        private CliWrapper.SocketSystem ss;
        private CliWrapper.Peer server;

        private void writeString(string str) {
            System.Console.WriteLine(str);
        }

        private void ProcessList(System.Collections.Generic.List<string> x) {}

        public void InitializeComponent() {
            this.StartupUri = new System.Uri(
                "MainWindow.xaml",
                System.UriKind.Relative
            );
            ss = new CliWrapper.SocketSystem();
            server = new CliWrapper.Peer(
                "Server 1", 8000,
                writeString,
                ProcessList,
                ProcessList
            );
        }

        public void Dispose() {
            server.Dispose();
            ss.Dispose();
        }

        [System.STAThread]
        public static void Main() {
            var app = new WPFWindow.App();
            app.InitializeComponent();
            app.Run();
            app.Dispose();
        }
    }
}
