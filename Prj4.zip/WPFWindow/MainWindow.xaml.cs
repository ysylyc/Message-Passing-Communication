﻿/////////////////////////////////////////////////////////////////////////////
// MainWindow.xaml.cs - Main window for CSE 687 Project #4                 //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Build a window for client. 
*
* Required Files:
* ---------------
* CLIWrapper.h, CLIWrapper.cpp
*
* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv Project4.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 27 APR 2015
*   first release
*/
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Forms;

namespace WPFWindow {
    /// <summary>
    /// MainWindow.xaml interaction logic
    /// </summary>
    public partial class MainWindow : Window, IDisposable {

        private CliWrapper.Peer client;

        private OpenFileDialog fileDialog = new OpenFileDialog();

        private bool isDownloading = false;
        private bool isUploading = false;
        // output result
        private void writeString(string str) {
            Dispatcher.Invoke(new Action<String>((s) => {
                consoleBlock.Text += s + "\n";
                consoleViewer.ScrollToEnd();
                if (isDownloading && s.Contains("All chunks")) {
                    isDownloading = false;
                    statusTbk.Text = "File is downloaded successfully.";
                }
                if (isUploading && s.Contains("sent to") &&
                    s.Contains("successfully")
                ) {
                    isUploading = false;
                    statusTbk.Text = "File is uploaded successfully.";
                }
            }), str);
        }
        // set categories
        private void setCategories(List<String> categories) {
            Dispatcher.Invoke(
                new Action<List<String>>((cats) => {
                    categoryLvw.Items.Clear();
                    foreach (var item in cats) {
                        categoryLvw.Items.Add(item);
                    }
                    statusTbk.Text = "Categories is got.";
                }),
                categories
            );
        }
        // set file list
        private void setFileList(List<String> fileList) {
            Dispatcher.Invoke(
                new Action<List<String>>((list) => {
                    fileLbx.Items.Clear();
                    foreach (var item in list) {
                        fileLbx.Items.Add(item);
                    }
                    statusTbk.Text = "Search result is got.";
                }),
                fileList
            );
        }
        // dispose
        public void Dispose() {
            client.Dispose();
        }
        // main window
        public MainWindow() {
            InitializeComponent();
            client = new CliWrapper.Peer(
                "Client 1", 9000,
                writeString,
                setCategories,
                setFileList
            );
            fileDialog.CheckFileExists = true;
            fileDialog.CheckPathExists = true;
            fileDialog.InitialDirectory = System.Windows.Forms.Application.StartupPath;
            fileDialog.Filter = "All files(*.*)|*.*";
            fileDialog.RestoreDirectory = true;
        }
        // clean button
        private void clearBtn_Click(object sender, RoutedEventArgs e) {
            consoleBlock.Text = "";
        }
        // send msg button
        private void sendMsgBtn_Click(object sender, RoutedEventArgs e) {
            if (msgTbx.Text == String.Empty) {
                msgTbx.Focus();
                statusTbk.Text = "Cannot send empty messages!";
                return;
            }
            client.sendMsgTo("127.0.0.1", 8000, msgTbx.Text);
            statusTbk.Text = "Message is sent.";
        }
        // get categories button
        private void getCategoriesBtn_Click(object sender, RoutedEventArgs e) {
            statusTbk.Text = "Try to get categories...";
            client.getDirectories("127.0.0.1", 8000);
        }
        // search button
        private void searchFileBtn_Click(object sender, RoutedEventArgs e) {
            if (categoryLvw.SelectedItem == null) {
                categoryLvw.Focus();
                statusTbk.Text = "Please select a category to search!";
                return;
            }
            if (filePatternTbx.Text == String.Empty) {
                filePatternTbx.Text = "*";
            }
            var path = (string)categoryLvw.SelectedItem;
            path = path.Substring(path.IndexOf("\\") + 1);
            var filePattern = filePatternTbx.Text;
            var textPattern = textPatternTbx.Text;
            client.searchFileAt("127.0.0.1", 8000, path, filePattern, textPattern);
            statusTbk.Text = "Search request is sent.";
        }
        // double click to download 
        private void fileLbx_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            if (fileLbx.SelectedItem == null) {
                fileLbx.Focus();
                statusTbk.Text = "Please select the file to download!";
            }
            var fileName = (string)fileLbx.SelectedItem;
            fileName = fileName.Substring(fileName.IndexOf("\\") + 1);
            if (System.Windows.MessageBox.Show(
                    "Download file " + fileName + " ?",
                    "Confirm",
                    MessageBoxButton.YesNo
                ) == MessageBoxResult.No
            ) {
                return;
            }
            isDownloading = true;
            client.downloadFileFrom("127.0.0.1", 8000, fileName, ".\\");
            statusTbk.Text = "Download request is sent.";
        }
        // upload button
        private void uploadFileBtn_Click(object sender, RoutedEventArgs e) {
            if (categoryLvw.SelectedItem == null) {
                categoryLvw.Focus();
                statusTbk.Text = "Please select a category to upload!";
                return;
            }
            if (fileDialog.ShowDialog() != System.Windows.Forms.DialogResult.OK) {
                return;
            }
            var path = (string)categoryLvw.SelectedItem;
            path = path.Substring(path.IndexOf("\\") + 1) + "\\";
            isUploading = true;
            statusTbk.Text = "Uploading file...";
            client.sendFileTo("127.0.0.1", 8000, fileDialog.FileName, path);
        }
    }
}
