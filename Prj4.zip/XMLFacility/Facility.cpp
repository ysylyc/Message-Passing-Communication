/////////////////////////////////////////////////////////////////////////////
// Facility.h - Provide additional functionality to XmlDocument object     //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include "Facility.h"

// display the whole tree
void Facility::showResult(){
	std::cout << pDoc->getDocEle()->toString();
}
// find the unique id attribute
sPtr Facility::findUniqueAttri(const std::string& attName){
	std::vector<sPtr> result;
	sPtr unique = nullptr;
	int count = 0;
	// find all elements have this id
	findAttri(result, pDoc->getDocEle(), attName);
	for (auto element : result){
		for (auto pair1 : element->attribute()){
			for (auto pair2 : element->attribute()){
				if (pair1.second == pair2.second){
					// if we got two times equalization, it's not unique
					if (count == 1){
						count = 0;
						break;
					}
					count++;
				}
			}
			// if only once we got equalization, it's unique
			if (count == 1){
				unique = element;
				return unique;
			}
		}
	}
	return unique;
}
// find all elements have this id and value
void Facility::findAttri(std::vector<sPtr>& result, const sPtr &element, const std::string& attName, const std::string& value){
	// if the value is default, we search all
	if (value == ""){
		for (auto pair : element->attribute()){
			if (attName == pair.first){
				result.push_back(element);
			}
		}
		if (element->children().size() != 0){
			for (auto child : element->children()){
				findAttri(result, child, attName, value);
			}
		}
	}
	else{
		for (auto pair : element->attribute()){
			if (attName == pair.first && value == pair.second){
				result.push_back(element);
			}
		}
		if (element->children().size() != 0){
			for (auto child : element->children()){
				findAttri(result, child, attName, value);
			}
		}
	}
}
// find all elements are match with tag
std::vector<sPtr> Facility::findEle(const std::string& tag){
	std::vector<sPtr> result;
	return result = pDoc->elements(tag).select();
}
// add child, found by tag
bool Facility::addChildByTag(const std::string& tag, const sPtr& child){
	std::vector<sPtr> result;
	result = findEle(tag);
	if (result.size() == 0){
		return false;
	}
	for (auto parent : result){
		parent->addChild(child);
	}
	return true;
}
// remove child, found by tag
bool Facility::removeChildByTag(const std::string& tag, const sPtr& child){
	std::vector<sPtr> result;
	bool success = false;
	result = findEle(tag);
	if (result.size() == 0){
		return false;
	}
	// if we got one remove successed, we return true
	for (auto parent : result){
		if (success == true){
			parent->removeChild(child);
		}
		else{
			success = parent->removeChild(child);
		}
	}
	return success;
}
// add child, found by id
bool Facility::addChildById(const std::string& id, const sPtr& child){
	std::vector<sPtr> result;
	findAttri(result, pDoc->getDocEle(), id);
	for (size_t i = 0; i != result.size(); i++){
		if (result[i]->getType() != "TaggedElement"){
			result.erase(result.begin() + i);
		}
	}
	if (result.size() == 0){
		return false;
	}
	for (auto parent : result){
		parent->addChild(child);
	}
	return true;
}
// remove child, found by id
bool Facility::removeChildById(const std::string& id, const sPtr& child){
	std::vector<sPtr> result;
	bool success = false;
	findAttri(result, pDoc->getDocEle(), id);
	for (size_t i = 0; i != result.size(); i++){
		if (result[i]->getType() != "TaggedElement"){
			result.erase(result.begin() + i);
		}
	}
	if (result.size() == 0){
		return false;
	}
	// if we got one remove successed, we return true
	for (auto parent : result){
		if (success == true){
			parent->removeChild(child);
		}
		else{
			success = parent->removeChild(child);
		}
	}
	return success;
}
// output the whole tree to a file
void Facility::toFile(const std::string& filename){
	std::ofstream output(filename, std::ios::out);
	if (output.fail()){
		std::cout << "Can't open file " << filename << std::endl;	
	}
	output << pDoc->getDocEle()->toString();
	output.close();
}
// check the input from user
void Facility::checkInput(int& input){
	while (1){
		std::cin >> input;
		if (std::cin.fail()){
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		}
		else if (input == 0 || input == 1){
			break;
		}
		std::cout << "Wrong, please re-input" << std::endl;
	}
	if (input == 0){
		std::cout << "Inpunt the string.\n";
	}
	else if (input == 1){
		std::cout << "Inpunt the filename.\n";
	}
}
// show command line
void Facility::showCommandLine(int argc, char** argv)
{
	std::cout << "\n  Commandline: ";
	for (int i = 0; i < argc; ++i)
	{
		std::cout << argv[i] << " ";
		if (i == argc - 1)
			std::cout << "\n  ";
	}
}
// read file and print it
void Facility::readFile(const std::string& filename){
	std::ifstream file(filename);
	char ch;
	std::cout << "  \nShow the content in file text.xml\n";
	while (!file.eof()){
		file.get(ch);
		std::cout << ch;
	}
	file.close();
}
//----< test stub >----------------------------------------------------------

#ifdef TEST_FACILITY
#include "Parser.h"
int main(){
	Parser parser;
	parser.setXmlSrc("LectureNote.xml", true);
	// create an parse tree in XmlDocument object doc
	XmlProcessing::XmlDocument doc(parser.parsering());
	Facility facility(&doc);
	facility.showResult();
	std::shared_ptr < XmlProcessing::AbstractXmlElement > jieguo = facility.findUniqueAttri("haha");
	std::cout << "\n" << jieguo->toString();
	std::vector<std::shared_ptr < XmlProcessing::AbstractXmlElement >> result = facility.findEle("title");
	for (auto i : result){
		std::cout << "\n" << i->toString();
	}
	std::shared_ptr < XmlProcessing::AbstractXmlElement > testchild = makeTaggedElement("ttttttttest");
	facility.addChildByTag("title", testchild);
	facility.showResult();
	std::cout << "\n\n";
}
#endif