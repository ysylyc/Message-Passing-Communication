/////////////////////////////////////////////////////////////////////////////
// Receiver.h - Receive message, and parse message via Message class.      //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "Receiver.h"

#include "../ApplicationHelpers/AppHelpers.h"

#include <exception>
#include <utility>
#include <cassert>

// Constructor of the Receiver class
Receiver::Receiver(unsigned int port)
	: listener(port, Socket::IP4), listenThread(listener.start(*this))
{
	if (listenThread.get_id() == std::thread::id()) {
		throw std::runtime_error("Port binding and/or listening failed.");
	}
	hEvent = ::CreateEventW(NULL, FALSE, FALSE, NULL);
}

// Pick a message from Receiver's message queue
MsgTuple Receiver::pickMsg() {
	return inQ.deQ();
}

// Push a message into Receiver's message queue (for shuting down the Peer)
void Receiver::pushMsg(Message && msg, std::unique_ptr<char> && p) {
	inQ.enQ(MsgTuple(std::move(msg), std::move(p)));
}

// The function of the receiving thread
void Receiver::operator()(Socket & socket_) {
	Socket * pSock;
	std::unique_ptr<char> buffer;
	size_t len;
	DWORD dwThreadId;

	{
		Socket socket = std::move(socket_);
		std::lock_guard<std::mutex> lock(mtx);
		dwThreadId = ::GetCurrentThreadId();
		auto tplIter = mapSocket.emplace(
			std::make_pair(dwThreadId, std::move(socket))
		);
		pSock = &(tplIter.first->second);	
	}
	Message msg;
	while (true) {
		auto str = pSock->recvString();
		if (str.empty()) {
			break;
		}
		msg = Message(str);
		str.~basic_string();
		msg.setSrcAddr(pSock->getPeerInfo(nullptr));
		if (msg.getType() == Message::DISCONNECT) {
			pushMsg(std::move(msg), std::move(buffer));
			break;
		}
		len = msg.getContentLen();
		if (len != 0) {
			buffer.reset(new char[len]);
			if (!pSock->recv(len, buffer.get())) {
				buffer.reset();
				break;
			}
		}
		pushMsg(std::move(msg), std::move(buffer));
		assert(buffer == nullptr);
	}

	assert(buffer == nullptr);
	{
		std::lock_guard<std::mutex> lock(mtx);
		mapSocket.erase(mapSocket.find(dwThreadId));
	}
	// Kernel object of this thread will be leaked if we don't close it.
	::CloseHandle(::GetCurrentThread());
	::SetEvent(hEvent);
}

// Stop the listening thread
void Receiver::stopListen() {
	listener.close();
	listenThread.join();
}

// Shutdown the receiver
void Receiver::shutdown() {
	// Wait about 5 seconds.
	for (int i = 0; i < 32; i++) {
		if (mapSocket.size() == 0) {
			return;
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(156));
	}
	{
		std::lock_guard<std::mutex> lock(mtx);
		for (auto & item : mapSocket) {
			item.second.shutDown();
			item.second.close();
		}
	}
	mtx.lock();
	while (mapSocket.size() != 0) {
		mtx.unlock();
		::WaitForSingleObject(hEvent, INFINITE);
		mtx.lock();
	}
	mtx.unlock();
	::CloseHandle(hEvent);
}
