#ifndef _PEER_H_
#define _PEER_H_
/////////////////////////////////////////////////////////////////////////////
// Peer.h - Contains a sender and a receiver class, to support             //
//			communication with each other.                                 //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* Provides four classes that supports communication with each other and peer 
* to peer communication channel.
* MsgTuple:
*  - Container for message objects and buffer.
* Receiver:
*  - Receive message, and parse message via Message class.
* Sender:
*  - Send message to one specified end.
* Peer:
*  - Combined the above three class, and process the message.
*  - Write file.
*  - Get msg from Receiver, send msg to sender.
* PeerWrapper:
*  - Wrap peer class for compatible with C++/CLI
*
* User interface:
* ---------------
* sendMsgTo(std::string const &, unsigned int, std::string const &);
* sendFileTo(std::string const &, unsigned int, std::string const &);
* disconnect(std::string const &, unsigned int);
* shutdown();
*
* Required Files:
* ---------------
* MsgTuple.h, MsgTuple.cpp, Sender.h, Sender.cpp,
* Receiver.h, Receiver.cpp, Cpp11-BlockingQueue.h, Cpp11-BlockingQueue.cpp

* Build Process:
* --------------
* From the Visual Studio Developer's Command Prompt:
* devenv project3_communication.sln /rebuild debug
*
* Maintenance History:
* --------------------
* - Ver 1.0 : 13 Apr 2015
*   first release
*/
#include "MsgTuple.h"
#include "Sender.h"
#include "Receiver.h"

#include "../Cpp11-BlockingQueue/Cpp11-BlockingQueue.h"

#include <condition_variable>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>

class Peer {
public:
using FuncWriteString = std::function<void(std::string const &)>;
using FuncProcessList = std::function<void(std::vector<std::string> const &)>;

	Peer(
		std::string const & peerName,
		unsigned int port,
		FuncWriteString writeString,
		FuncProcessList setCategories,
		FuncProcessList setFileList
	);

	Peer(Peer const &) = delete;
	Peer(Peer &&) = delete;
	Peer & operator=(Peer const &) = delete;
	Peer & operator=(Peer &&) = delete;

	~Peer();

	void sendMsgTo(std::string const &, unsigned int, std::string const &);
	void sendFileTo(std::string const &, unsigned int, std::string const &, std::string const &);
	void downloadFileFrom(std::string const &, unsigned int, std::string const &, std::string const &);
	void getDirectories(std::string const &, unsigned int);
	void searchFileAt(std::string const &, unsigned int, std::string const &, std::string const &, std::string const &);

	void disconnect(std::string const &, unsigned int);
	void shutdown();

private:

	void startProcessing();
	void handleFileUpload();

	bool processSwitch(Message && msg, std::unique_ptr<char> && buffer);

	void processTextMsg(Message && msg, std::unique_ptr<char> && buffer);
	void processFileReceipt(Message && msg);
	void processDownloadReq(Message && msg, std::unique_ptr<char> && buffer);
	void processSearchReq(Message && msg, std::unique_ptr<char> && buffer);
	void processSearchReceipt(Message && msg, std::unique_ptr<char> && buffer);
	void processDisconnect(Message && msg);

	bool checkDirAndFileAvailable(Message & msg, std::string & dir, std::string & raw, std::string & incomplete);
	void writeChunkToFile(Message & msg, std::unique_ptr<char> && buffer, std::string const & raw, std::string const & incomplete);
	void checkChunkSituation(Message && msg, std::string & raw, char const * incomplete);

	std::string addName(std::string const & name);

	struct MyEvent {
		HANDLE handle;

		MyEvent();
		~MyEvent();
		void Set();
		void Wait();
	};

	FuncWriteString writeString;
	FuncProcessList setCategories;
	FuncProcessList setFileList;

	std::string peerName;
	std::string localAddr;
	unsigned int localPort;

	bool isShutdown;

	std::unordered_map<std::string, std::string> nameCache;

	// Initialize receiver first, then sender
	Receiver receiver;
	Sender sender;
	BlockingQueue<MsgTuple> fileChunkQ;

	std::mutex mtx;
	std::condition_variable waitCV;
	volatile bool flagHang;

	MyEvent evtProcessing;
	MyEvent evtFile;

	std::thread fileThread, processingThread;
};

#endif//_PEER_H_
