/////////////////////////////////////////////////////////////////////////////
// Sender.h - Send message to one specified end.                           //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "Sender.h"

#include <assert.h>
#include <string>
#include <utility>

// Constructor of the Sender class
Sender::Sender(Sender::FuncWriteString func) :
	writeString(std::move(func)), senderThread(&Sender::threadFunc, this) { }

// Send a message to a remote peer
void Sender::sendMsg(Message && msg, std::unique_ptr<char> && p) {
	auto dst = std::make_pair(
		msg.getDstAddr(),
		msg.getDstPort()
	);
	auto iterConn = mapSocket.find(dst);
	if (iterConn == mapSocket.end()) {
		if (msg.getType() == Message::DISCONNECT) {
			writeString("Cannot connect to " + dst.first + ":" + std::to_string(dst.second) + " . Message will be discarded.");
			return;
		}
		SocketConnecter socket;
		if (!socket.connect(dst.first, dst.second)) {
			writeString("Cannot connect to " + dst.first + ":" + std::to_string(dst.second) + " . Message will be discarded.");
			return;
		}
		mapSocket.emplace(std::make_pair(std::move(dst), std::move(socket)));
	} else {
		msg.setSrcAddr(std::string(iterConn->first.first));
		SocketConnecter * pConn = &(iterConn->second);
		if (!pConn->validState()) {
			mapSocket.erase(iterConn);
			writeString("Cannot connect to " + dst.first + ":" + std::to_string(dst.second) + " . Message will be discarded.");
			return;
		}
	}
	outQ.enQ(MsgTuple(std::move(msg), std::move(p)));
}

// The function of the sending thread
void Sender::threadFunc() {
	SocketConnecter * pConn;
	Message msg;
	std::unique_ptr<char> buffer;
	// Pick messages and send them
	while (true) {
		assert(buffer == nullptr);
		auto tplMsg = outQ.deQ();
		msg = std::move(tplMsg.msg);
		std::swap(buffer, tplMsg.buffer);
		if (msg.getType() == Message::EXIT) {
			break;
		}
		auto dst = std::make_pair(
			msg.getDstAddr(),
			msg.getDstPort()
		);
		pConn = &mapSocket[dst];
		if (!pConn->sendString(msg.toString()) ||
			(buffer != nullptr && !pConn->send(
				msg.getContentLen(), buffer.get()
			))
		) {
			buffer.reset();
			continue;
		}
		if (msg.getType() == Message::DISCONNECT) {
			mapSocket.erase(mapSocket.find(dst));
		}
		buffer.reset();
	}

	assert(buffer == nullptr);
	for (auto & item : mapSocket) {
		item.second.sendString((Message::buildDisconnect(msg.getSrcAddr(), msg.getSrcPort(), item.first.first, item.first.second)).toString());
	}
}

// Shutdown the sending thread
void Sender::shutdown(std::string const & localAddr, unsigned int localPort) {
	outQ.enQ(MsgTuple(Message::buildExit(localAddr, localPort), nullptr));
	senderThread.join();
	mapSocket.clear();
}
