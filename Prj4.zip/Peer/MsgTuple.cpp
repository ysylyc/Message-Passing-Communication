/////////////////////////////////////////////////////////////////////////////
// MsgTuple.h - Container for message objects and buffer.                  //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "MsgTuple.h"

// Default constructor of MsgTuple
MsgTuple::MsgTuple() : buffer(nullptr) { }

// Construct a MsgTuple object with a message object and a buffer
MsgTuple::MsgTuple(Message && m, std::unique_ptr<char> && p)
	: msg(std::move(m)), buffer(std::move(p)) { }

// Move constructor of MsgTuple
MsgTuple::MsgTuple(MsgTuple && m) {
	*this = std::move(m);
}

// Move assignment operator
MsgTuple & MsgTuple::operator=(MsgTuple && m) {
	std::swap(msg, m.msg);
	std::swap(buffer, m.buffer);

	return *this;
}
