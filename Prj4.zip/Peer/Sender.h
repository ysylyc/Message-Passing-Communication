#ifndef _SENDER_H_
#define _SENDER_H_
/////////////////////////////////////////////////////////////////////////////
// Sender.h - Send message to one specified end.                           //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Required Files :
*---------------
* Sender.h, Sender.cpp
*
* Build Process :
*--------------
* From the Visual Studio Developer's Command Prompt:
* devenv project3_communication.sln / rebuild debug
*
* Maintenance History :
*--------------------
* Ver 1.0 : 13 Apr 2015
* first release
*/
#include "MsgTuple.h"

#include "../Cpp11-BlockingQueue/Cpp11-BlockingQueue.h"
#include "../Message/Message.h"
#include "../Sockets/Sockets.h"

#include <functional>
#include <memory>
#include <thread>
#include <unordered_map>

namespace std {
	template<>
	struct hash<std::pair<std::string, unsigned int>> {
		typedef std::pair<std::string, unsigned int> argument_type;
		typedef std::size_t result_type;

		std::hash<std::string> strHasher;
		std::hash<unsigned int> uintHasher;

		hash() : strHasher(), uintHasher() {}

		result_type operator()(argument_type const & s) const {
			return strHasher(s.first) ^ uintHasher(s.second);
		}
	};
}

class Sender {
public:
using FuncWriteString = std::function<void(std::string const &)>;

	Sender(FuncWriteString func);

	Sender(Sender const &) = delete;
	Sender(Sender &&) = delete;
	Sender & operator=(Sender const &) = delete;
	Sender & operator=(Sender &&) = delete;

	void sendMsg(Message && msg, std::unique_ptr<char> && p);
	void shutdown(std::string const &, unsigned int);

private:
	void threadFunc();

	FuncWriteString writeString;
	BlockingQueue<MsgTuple> outQ;
	std::unordered_map<
		std::pair<
			std::string,
			unsigned int
		>,
		SocketConnecter
	> mapSocket;
	std::thread senderThread;
};

#endif//_SENDER_H_
