#ifndef _RECEIVER_H_
#define _RECEIVER_H_
/////////////////////////////////////////////////////////////////////////////
// Receiver.h - Receive message, and parse message via Message class.      //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Required Files :
*---------------
* Receiver.h, Receiver.cpp
*
* Build Process :
*--------------
* From the Visual Studio Developer's Command Prompt:
* devenv project3_communication.sln / rebuild debug
*
* Maintenance History :
*--------------------
* Ver 1.0 : 13 Apr 2015
* first release
*/
#include "MsgTuple.h"

#include "../Cpp11-BlockingQueue/Cpp11-BlockingQueue.h"
#include "../Message/Message.h"
#include "../Sockets/Sockets.h"

#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>

class Receiver {
public:
	Receiver(unsigned int port);
	Receiver(Receiver const &) = delete;
	Receiver(Receiver &&) = delete;
	Receiver & operator=(Receiver const &) = delete;
	Receiver & operator=(Receiver &&) = delete;

	MsgTuple pickMsg();
	void pushMsg(Message && msg, std::unique_ptr<char> && p);
	void operator()(Socket &);
	void stopListen();
	void shutdown();

private:
	BlockingQueue<MsgTuple> inQ;
	std::mutex mtx;
	HANDLE hEvent;
	std::unordered_map<DWORD, Socket> mapSocket;
	SocketListener listener;
	std::thread listenThread;
};

#endif//_RECEIVER_H_
