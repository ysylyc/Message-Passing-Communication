#ifndef _PEERWRAPPER_H_
#define _PEERWRAPPER_H_
/////////////////////////////////////////////////////////////////////////////
// PeerWrapper.h - wrap native peer class                                  //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Required Files :
*---------------
* PeerWrapper.h, PeerWrapper.cpp
*
* Build Process :
*--------------
* From the Visual Studio Developer's Command Prompt:
* devenv project4.sln / rebuild debug
*
* Maintenance History :
*--------------------
* Ver 1.0 : 13 Apr 2015
* first release
*/
#include <functional>
#include <string>
#include <vector>

class Peer;

class PeerWrapper {
public:

using FuncWriteString = std::function<void(std::string const &)>;
using FuncProcessList = std::function<void(std::vector<std::string> const &)>;

	PeerWrapper(
		std::string const & peerName,
		unsigned int port,
		FuncWriteString writeString,
		FuncProcessList setCategories,
		FuncProcessList setFileList
	);

	PeerWrapper(PeerWrapper const &) = delete;
	PeerWrapper(PeerWrapper &&) = delete;
	PeerWrapper & operator=(PeerWrapper const &) = delete;
	PeerWrapper & operator=(PeerWrapper &&) = delete;

	~PeerWrapper();

	void sendMsgTo(std::string const &, unsigned int, std::string const &);
	void sendFileTo(std::string const &, unsigned int, std::string const &, std::string const &);
	void downloadFileFrom(std::string const &, unsigned int, std::string const &, std::string const &);
	void getDirectories(std::string const &, unsigned int);
	void searchFileAt(std::string const &, unsigned int, std::string const &, std::string const &, std::string const &);

	void disconnect(std::string const &, unsigned int);
	void shutdown();

private:
	Peer * peer;
};

class SocketSystem;

class SocketSystemWrapper {
public:
	SocketSystemWrapper();
	~SocketSystemWrapper();

private:
	SocketSystem * ss;
};

#endif//_PEERWRAPPER_H_
