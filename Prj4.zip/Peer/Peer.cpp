/////////////////////////////////////////////////////////////////////////////
// Peer.h - Contains a sender and a receiver class, to support             //
//			communication with each other.                                 //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "Peer.h"

#include "../FileSystem/FileSystem.h"
#include "../FileSearch/FileSearch.h"
#include "../Message/Message.h"
#include "../Sockets/Sockets.h"
#include "../XMLFacility/Parser.h"
#include "../XMLFacility/XmlElement.h"
#include "../XMLFacility/XmlDocument.h"

#include <assert.h>
#include <exception>
#include <memory>
#include <utility>
#include <cstdio>

// Constructor of MyEvent class
Peer::MyEvent::MyEvent() : handle(::CreateEventW(NULL, FALSE, FALSE, NULL)) { }
// Destructor of MyEvent class
Peer::MyEvent::~MyEvent() { ::CloseHandle(handle); }
// Set the event (i.e. signal the event)
void Peer::MyEvent::Set() { ::SetEvent(handle); }
// Wait on the event
void Peer::MyEvent::Wait() { ::WaitForSingleObject(handle, INFINITE); }

// Constructor of Peer class
Peer::Peer(
	std::string const & peerName_,
	unsigned int port,
	Peer::FuncWriteString writeString_,
	Peer::FuncProcessList setCategories_,
	Peer::FuncProcessList setFileList_
) : writeString(std::move(writeString_)),
	setCategories(std::move(setCategories_)),
	setFileList(std::move(setFileList_)),
	peerName(peerName_ + ": "), localAddr("0.0.0.0"), localPort(port),
	isShutdown(false), receiver(port), sender(writeString),
	fileThread(&Peer::handleFileUpload, this),
	processingThread(&Peer::startProcessing, this)
{
	writeString(peerName + localAddr + ":" + std::to_string(port) + " started.");
}

// Destructor of Peer class
Peer::~Peer() {
	if (!isShutdown) {
		shutdown();
	}
}

// Check if a network name is in name cache:
//  If not, resolve it, and save the address in name cache
//  Otherwise, return the cached name
std::string Peer::addName(std::string const & name) {
	std::string retValue;
	auto iterCache = nameCache.find(name);
	if (iterCache == nameCache.end()) {
		addrinfo hints, * pResult;
		char tempName[INET6_ADDRSTRLEN];
		::memset(&hints, 0, sizeof(addrinfo));
		hints.ai_flags = AI_CANONNAME;
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = 0;
		if (::getaddrinfo(name.c_str(), nullptr, &hints, &pResult) == 0) {
			::inet_ntop(AF_INET, &((sockaddr_in *)pResult->ai_addr)->sin_addr, tempName, INET6_ADDRSTRLEN);
			::freeaddrinfo(pResult); 
			retValue = std::string(tempName);
			nameCache.emplace(std::make_pair(name, retValue));
		}
	} else {
		retValue = iterCache->second;
	}
	return retValue;
}

// Send a text message to a peer
void Peer::sendMsgTo(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const & message
) {
	std::string convAddr = addName(remoteAddr);
	if (convAddr.empty()) {
		writeString(peerName + "Cannot find a host with name " + remoteAddr + " .");
		return;
	}
	std::unique_ptr<char> buffer(new char[message.size() + 1]);
	std::memcpy(buffer.get(), message.c_str(), message.size());
	buffer.get()[message.size()] = 0;
	auto msg = Message::buildTextMsg(
		localAddr, localPort, convAddr, remotePort, message
	);
	sender.sendMsg(std::move(msg), std::move(buffer));
	writeString(peerName + "Message " + message + " is enqueued.");
}

// Send a file to a peer
//  remotePath should be empty or end with a '\\'
void Peer::sendFileTo(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const & fileName,
	std::string const & remotePath
) {
	size_t const chunkSize = 1024;
	size_t sizeRead;
	std::unique_ptr<char> buffer;
	unsigned int chunkCount, chunkNo = 0;
	std::string convAddr = addName(remoteAddr);
	if (convAddr.empty()) {
		writeString(peerName + "Cannot find a host with name " + remoteAddr + " .");
		return;
	}
	FileSystem::File file(fileName);
	file.open(FileSystem::File::in, false, FileSystem::File::binary);
	if (!file.isGood()) {
		writeString(peerName + "Failed to open file " + fileName + " .");
		return;
	}
		FileSystem::FileInfo info(fileName);
		chunkCount = info.size() / chunkSize;
		if ((info.size() % chunkSize) != 0) {
			chunkCount++;
		}
		if (chunkCount == 0) {
			chunkCount++;
		}
	writeString(peerName + "File " + fileName + " has " + std::to_string(chunkCount) + " chunks.");
	std::string rawFileName = remotePath + fileName.substr(fileName.find_last_of('\\') + 1);
	do {
		buffer.reset(new FileSystem::Byte[chunkSize]);
		try {
			sizeRead = file.getBuffer(chunkSize, buffer.get());
		} catch (std::exception &) {
			sizeRead = 0;
			buffer.reset();
		}
		auto msg = Message::buildFileMsg(
			localAddr, localPort, convAddr, remotePort,
			rawFileName, sizeRead, chunkCount, chunkNo
		);
		sender.sendMsg(std::move(msg), std::move(buffer));
		chunkNo++;
	} while (sizeRead == chunkSize);
	writeString(peerName + "All " + std::to_string(chunkNo) + " Chunks of file " + rawFileName + " have been pushed into the send queue.");
	return;
}

// download a file from a peer
// localPath should be empty or end with a '\\'
void Peer::downloadFileFrom(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const & fileName,
	std::string const & localPath
) {
	std::string convAddr = addName(remoteAddr);
	if (convAddr.empty()) {
		writeString(peerName + "Cannot find a host with name " + remoteAddr + " .");
		return;
	}
	std::unique_ptr<char> buf(new char[localPath.size() + 1]);
	::memcpy(buf.get(), localPath.c_str(), localPath.size());
	buf.get()[localPath.size()] = 0;
	sender.sendMsg(Message::buildDownload(
		localAddr, localPort, convAddr, remotePort, fileName, localPath.size() + 1
	), std::move(buf));
}
// get categories from remote peer
void Peer::getDirectories(std::string const & remoteAddr, unsigned int remotePort) {
	std::string convAddr = addName(remoteAddr);
	if (convAddr.empty()) {
		writeString(peerName + "Cannot find a host with name " + remoteAddr + " .");
		return;
	}
	sender.sendMsg(Message::buildSearch(
		localAddr, localPort, convAddr, remotePort, "\\"
	), nullptr);
}
// search file
void Peer::searchFileAt(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const & path,
	std::string const & filePattern,
	std::string const & textPattern
) {
	std::string convAddr = addName(remoteAddr);
	if (convAddr.empty()) {
		writeString(peerName + "Cannot find a host with name " + remoteAddr + " .");
		return;
	}
	auto root = XmlProcessing::makeTaggedElement("parameters");
	root->addAttrib("filepattern", filePattern);
	root->addAttrib("textpattern", textPattern);
	auto body = root->toString();
	std::unique_ptr<char> buf(new char[body.size() + 1]);
	::memcpy(buf.get(), body.c_str(), body.size());
	buf.get()[body.size()] = 0;
	auto msg = Message::buildSearch(localAddr, localPort, convAddr, remotePort, path);
	msg.setContentLen(body.size() + 1);
	sender.sendMsg(std::move(msg), std::move(buf));
}

// Disconnect from a peer
void Peer::disconnect(
	std::string const & remoteAddr,
	unsigned int remotePort
) {
	std::string convAddr = addName(remoteAddr);
	if (convAddr.empty()) {
		writeString(peerName + "Cannot find a host with name " + remoteAddr + " .");
		return;
	}

	sender.sendMsg(
		Message::buildDisconnect(
			localAddr, localPort, convAddr, remotePort
		),
		nullptr
	);
}

// The function of processing thread
void Peer::startProcessing() {
	Message msg;
	std::unique_ptr<char> buffer;

	do {
		if (flagHang) {
			evtProcessing.Set();
			std::unique_lock<std::mutex> lock(mtx);
			waitCV.wait(lock, [this] { return !flagHang; });
		}
		auto tplMsg = receiver.pickMsg();
		std::swap(msg, tplMsg.msg);
		std::swap(buffer, tplMsg.buffer);
		if (msg.isIllegal()) {
			fileChunkQ.enQ(MsgTuple(std::move(msg), nullptr));
			continue;
		}
	} while (!processSwitch(std::move(msg), std::move(buffer)));

	fileThread.join();
}

// Handling all kinds of messages
bool Peer::processSwitch(Message && msg, std::unique_ptr<char> && buffer) {
	switch (msg.getType()) {
	case Message::TEXT_MSG:
		processTextMsg(std::move(msg), std::move(buffer));
		break;
	case Message::TEXT_RECEIPT:
		writeString(peerName + "Message " + msg.getFileName() + " sent to " + msg.getSrcAddr() + ':' + std::to_string(msg.getSrcPort()) + " succeesfully.");
		break;
	case Message::UPLOAD_FILE:
		fileChunkQ.enQ(MsgTuple(std::move(msg), std::move(buffer)));
		break;
	case Message::FILE_RECEIPT:
		processFileReceipt(std::move(msg));
		break;
	case Message::DOWNLOAD_FILE:
		processDownloadReq(std::move(msg), std::move(buffer));
		break;
	case Message::SEARCH_FILE:
		processSearchReq(std::move(msg), std::move(buffer));
		break;
	case Message::SEARCH_RECEIPT:
		processSearchReceipt(std::move(msg), std::move(buffer));
		break;
	case Message::DISCONNECT:
		processDisconnect(std::move(msg));
		break;
	case Message::EXIT:
		fileChunkQ.enQ(MsgTuple(std::move(msg), std::move(buffer)));
		return true;
	}
	return false;
}

// Handling text messages
void Peer::processTextMsg(Message && msg, std::unique_ptr<char> && buffer) {
	writeString(peerName + "Received text message " + msg.getFileName() + " from " + msg.getSrcAddr() + ":" + std::to_string(msg.getSrcPort()) + " : \n\t" + std::string(buffer.get()));
	msg.turnToReceipt();
	buffer.reset();
	sender.sendMsg(std::move(msg), std::move(buffer));
}

// Handling file receipt messages
void Peer::processFileReceipt(Message && msg) {
	if (msg.isNegative(nullptr)) {
		unsigned int chunkNo;
		msg.isNegative(&chunkNo);
		writeString(peerName + "File " + msg.getFileName() + " sent to " + msg.getSrcAddr() + ':' + std::to_string(msg.getSrcPort()) + " failed: chunk " + std::to_string(chunkNo) + "/" + std::to_string(msg.getChunkCount()) + " is refused.");
	} else {
		writeString(peerName + "File " + msg.getFileName() + " sent to " + msg.getSrcAddr() + ':' + std::to_string(msg.getSrcPort()) + " successfully.");
	}
}

// Handling download requests
void Peer::processDownloadReq(Message && msg, std::unique_ptr<char> && buf) {
	if (msg.isReceipt() && msg.isNegative(nullptr)) {
		writeString(peerName + "Download request of file " + msg.getFileName() + " is refused since it does not exist.");
		return;
	}
	std::string fileName = ".\\" + std::to_string(localPort) + "\\" + msg.getSrcAddr() + "-" + std::to_string(msg.getSrcPort()) + "\\" + msg.getFileName();
	if (!FileSystem::File::exists(fileName)) {
		msg.turnToReceipt(true);
		sender.sendMsg(std::move(msg), nullptr);
		return;
	}
	sendFileTo(msg.getSrcAddr(), msg.getSrcPort(), fileName, std::string(buf.get()));
}
// Handling search requests
void Peer::processSearchReq(Message && msg, std::unique_ptr<char> && buf) {
	auto localPath = ".\\" + std::to_string(localPort) + "\\" + msg.getSrcAddr() + "-" + std::to_string(msg.getSrcPort());
	if (msg.getFileName() == "\\") {
		assert(buf == nullptr);
		auto dirs = FileSystem::Directory::getDirectories(localPath, "*");
		auto root = XmlProcessing::makeTaggedElement("results");
		for (auto const & dir : dirs) {
			if (dir == "." || dir == "..") 
				continue;
			auto result = XmlProcessing::makeTaggedElement("dir");
			result->addAttrib("name", peerName + "\\" + dir);
			root->addChild(result);
		}
		auto body = root->toString();
		buf.reset(new char[body.size() + 1]);
		::memcpy(buf.get(), body.c_str(), body.size());
		buf.get()[body.size()] = 0;
		msg.turnToReceipt();
		msg.setContentLen(body.size() + 1);
		sender.sendMsg(std::move(msg), std::move(buf));
	} else {
		Parser parser;
		std::string params(buf.get()), filePattern, textPattern;
		parser.setXmlSrc(params, false);
		XmlProcessing::XmlDocument xmlDoc(parser.parsering());
		auto root = xmlDoc.element("parameters").select()[0];
		for (auto const & attrib : root->attribute()) {
			if (attrib.first == "filepattern") 
				filePattern = attrib.second;
			if (attrib.first == "textpattern") 
				textPattern = attrib.second;
		}
		root.reset();
		auto files = FileSearch::getFiles(localPath + "\\", msg.getFileName(), filePattern, textPattern);
		root = XmlProcessing::makeTaggedElement("results");
		for (auto const & fileName : files) {
			auto fileElem = XmlProcessing::makeTaggedElement("file");
			fileElem->addAttrib("name", peerName + "\\" + fileName);
			root->addChild(fileElem);
		}
		auto body = root->toString();
		buf.reset(new char[body.size() + 1]);
		::memcpy(buf.get(), body.c_str(), body.size());
		buf.get()[body.size()] = 0;
		msg.turnToReceipt();
		msg.setContentLen(body.size() + 1);
		sender.sendMsg(std::move(msg), std::move(buf));
	}
}
// Handling search receipt
void Peer::processSearchReceipt(Message && msg, std::unique_ptr<char> && buf) {
	Parser parser;
	std::string results(buf.get());
	parser.setXmlSrc(results, false);
	XmlProcessing::XmlDocument xmlDoc(parser.parsering());
	auto root = xmlDoc.element("results").select()[0];
	std::vector<std::string> items;
	results = "\n";
	for (auto const & name : root->children()) {
		items.push_back(name->attribute()[0].second);
		results += "    " + name->attribute()[0].second + "\n";
	}
	if (msg.getFileName() == "\\") {
		setCategories(items);
		writeString(peerName + "Directories' name received:" + results);
	} else {
		setFileList(items);
		writeString(peerName + "Files' name received:" + results);
	}
}

// Handling disconnect messages
void Peer::processDisconnect(Message && msg) {
	if (!msg.isReceipt()) {
		writeString(peerName + "Disconnecting from " + msg.getSrcAddr() + ':' + std::to_string(msg.getSrcPort()) + '.');
		msg.turnToReceipt();
		sender.sendMsg(std::move(msg), nullptr);
	} else {
		writeString(peerName + "Disconnected from " + msg.getSrcAddr() + ':' + std::to_string(msg.getSrcPort()) + '.');
	}
}

// The function of file handling thread
void Peer::handleFileUpload() {
	Message msg;

	while (true) {
		if (flagHang) {
			evtFile.Set();
			std::unique_lock<std::mutex> lock(mtx);
			waitCV.wait(lock, [this] { return !flagHang; });
		}

		auto tplMsg = fileChunkQ.deQ();
		msg = std::move(tplMsg.msg);
		std::unique_ptr<char> buffer(tplMsg.buffer.release());

		if (msg.isIllegal()) {
			continue;
		}
		
		if (msg.getType() == Message::EXIT) {
			break;
		}

		writeString(peerName + "File " + msg.getFileName() + " from " + msg.getSrcAddr() + ':' + std::to_string(msg.getSrcPort()) + " : chunk " + std::to_string(msg.getChunkNo()) + "/" + std::to_string(msg.getChunkCount()) + ", chunk size " + std::to_string(msg.getContentLen()) + " bytes.");
		
		std::string writeDir, fileName, fnIncomp;
		if (!checkDirAndFileAvailable(msg, writeDir, fileName, fnIncomp)) {
			if (msg.getChunkNo() + 1 == msg.getChunkCount()) {
				msg.turnToReceipt();
				sender.sendMsg(std::move(msg), nullptr);
			}
			continue;
		}
		writeChunkToFile(msg, std::move(buffer), fileName, fnIncomp);
		checkChunkSituation(std::move(msg), fileName, fnIncomp.c_str());
	}
}

// Check if the directory and the file are available to write
bool Peer::checkDirAndFileAvailable(
	Message & msg,
	std::string & dir,
	std::string & raw,
	std::string & incomplete
) {
	dir = ".\\" + std::to_string(localPort);
	if (!FileSystem::Directory::exists(dir) &&
		!FileSystem::Directory::create(dir)
	) {
		writeString(peerName + "Cannot create directory " + dir);
		return false;
	}
	dir += "\\" + msg.getSrcAddr() + "-" + std::to_string(msg.getSrcPort());
	if (!FileSystem::Directory::exists(dir) &&
		!FileSystem::Directory::create(dir)
	) {
		writeString(peerName + "Cannot create directory " + dir);
		return false;
	}
	auto backslashpos = msg.getFileName().find_last_of('\\');
	if (backslashpos != std::string::npos) {
		auto appendDir = dir + "\\" + msg.getFileName().substr(0, backslashpos);
		if (!FileSystem::Directory::exists(appendDir) &&
			!FileSystem::Directory::create(appendDir)
		) {
			writeString(peerName + "Cannot create directory " + appendDir);
			return false;
		}
	}
	raw = dir + "\\" + msg.getFileName();
	incomplete = raw + "_incomplete";
	if (msg.getChunkNo() == 0 &&
		(FileSystem::File::exists(raw) ||
		 FileSystem::File::exists(incomplete))
	) {
		writeString(peerName + "File " + raw + " exists, cannot write over it.");
		msg.turnToReceipt(true);
		sender.sendMsg(std::move(msg), nullptr);
		return false;
	} else if (msg.getChunkNo() != 0 && !FileSystem::File::exists(incomplete)) {
		writeString(peerName + "File " + raw + " does not exist, cannot write chunks of it.");
		msg.turnToReceipt(true);
		sender.sendMsg(std::move(msg), nullptr);
		return false;
	}
	return true;
}

// Write file chunks
void Peer::writeChunkToFile(
	Message & msg,
	std::unique_ptr<char> && buffer,
	std::string const & raw,
	std::string const & incomplete
) {
	FileSystem::File file(incomplete);

	if (!file.open(
		FileSystem::File::out,
		msg.getChunkNo() > 0,
		FileSystem::File::binary
	)) {
		writeString(peerName + "Cannot open/create file " + raw);
		return;
	}
	try {
		file.putBuffer(msg.getContentLen(), buffer.get());
	} catch (std::exception &) {
		writeString(peerName + "Cannot write to file " + raw);
	}
	file.close();
}

// Check if the message is the last chunk of a file, and send the receipt
void Peer::checkChunkSituation(
	Message && msg,
	std::string & raw,
	char const * incomplete
) {
	if (msg.getChunkNo() + 1 == msg.getChunkCount()) {
		std::rename(incomplete, raw.c_str());
		msg.turnToReceipt();
		sender.sendMsg(std::move(msg), nullptr);
		writeString(
			peerName + "All chunks of file " + raw + " has been written to disk."
		);
	} else {
		writeString(
			peerName + "Chunk " + std::to_string(msg.getChunkNo()) + "/" +
				std::to_string(msg.getChunkCount()) + " of file " + raw +
				" is written to disk."
		);
	}
}

// Shutdown the peer
void Peer::shutdown() {
	// Stop listening thread
	receiver.stopListen();

	// Hang up processing thread and file thread
	flagHang = true;
	receiver.pushMsg(Message(), nullptr);
	evtProcessing.Wait();
	evtFile.Wait();

	// Stop sender
	sender.shutdown(localAddr, localPort);

	// Stop receiver
	receiver.shutdown();

	// Ensure processing thread and file thread will exit
	receiver.pushMsg(Message::buildExit(localAddr, localPort), nullptr);

	// Wakeup processing thread and file thread
	flagHang = false;
	waitCV.notify_all();

	// Wait processing thread and file thread to exit
	processingThread.join();

	isShutdown = true;

	writeString(peerName + localAddr + ":" + std::to_string(localPort) + " is shutdown.");
}

//----< test buffer handling >-----------------------------------------------
#ifdef TEST_PEER
int main(){
	SocketSystem::SocketSystem();
	Peer client1("client1","localhost",8080);
}
#endif