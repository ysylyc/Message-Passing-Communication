/////////////////////////////////////////////////////////////////////////////
// PeerWrapper.h - wrap native peer class                                  //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "PeerWrapper.h"

#include "Peer.h"

#include "..\Sockets\Sockets.h"
// Constructor
PeerWrapper::PeerWrapper(
	std::string const & peerName,
	unsigned int port,
	FuncWriteString writeString,
	FuncProcessList setCategories,
	FuncProcessList setFileList
) {
	peer = new Peer(peerName, port, writeString, setCategories, setFileList);
}
// Destructor
PeerWrapper::~PeerWrapper() {
	delete peer;
}
// Send a text message to a peer
void PeerWrapper::sendMsgTo(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const &message
) {
	peer->sendMsgTo(remoteAddr, remotePort, message);
}
// Send a file to a peer
void PeerWrapper::sendFileTo(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const & fileName,
	std::string const & remotePath
) {
	peer->sendFileTo(remoteAddr, remotePort, fileName, remotePath);
}
// download a file from a peer
void PeerWrapper::downloadFileFrom(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const & fileName,
	std::string const & localPath
) {
	peer->downloadFileFrom(remoteAddr, remotePort, fileName, localPath);
}
// get categories from remote peer
void PeerWrapper::getDirectories(
	std::string const & remoteAddr,
	unsigned int remotePort
) {
	peer->getDirectories(remoteAddr, remotePort);
}
// search file
void PeerWrapper::searchFileAt(
	std::string const & remoteAddr,
	unsigned int remotePort,
	std::string const & path,
	std::string const & filePattern,
	std::string const & textPattern
) {
	peer->searchFileAt(remoteAddr, remotePort, path, filePattern, textPattern);
}
// Disconnect from a peer
void PeerWrapper::disconnect(
	std::string const & remoteAddr,
	unsigned int remotePort
) {
	peer->disconnect(remoteAddr, remotePort);
}
// Shutdown the peer
void PeerWrapper::shutdown() {
	peer->shutdown();
}
// Constructor for socket system
SocketSystemWrapper::SocketSystemWrapper() {
	ss = new SocketSystem();
}
// Destructor for socket system
SocketSystemWrapper::~SocketSystemWrapper() {
	delete ss;
}


