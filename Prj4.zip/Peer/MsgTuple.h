#ifndef _MSGTUPLE_H_
#define _MSGTUPLE_H_
/////////////////////////////////////////////////////////////////////////////
// MsgTuple.h - Container for message objects and buffer.                  //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
/*
* Required Files :
*---------------
*MsgTuple.h, MsgTuple.cpp
*
* Build Process :
*--------------
* From the Visual Studio Developer's Command Prompt:
* devenv project3_communication.sln / rebuild debug
*
* Maintenance History :
*--------------------
* -Ver 1.0 : 13 Apr 2015
* first release
*/
#include "../Message/Message.h"

#include <memory>

struct MsgTuple {
	Message msg;
	std::unique_ptr<char> buffer;

	MsgTuple();
	MsgTuple(Message &&, std::unique_ptr<char> &&);
	MsgTuple(MsgTuple &&);
	MsgTuple(MsgTuple const &) = delete;
	MsgTuple & operator=(MsgTuple &&);
	MsgTuple & operator=(MsgTuple const &) = delete;
};

#endif //_MSGTUPLE_H_
