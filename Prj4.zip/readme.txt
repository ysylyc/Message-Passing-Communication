You could find a button called "Get Categories" under "File List" tab, and press it would show you all categories that server has. And then you could choose one of them to do operations(download, upload, search).

The client could see the result at GUI, the server would display result at console.

You could input *.h, *.* or *..etc to limit the file patterns. And regular expression to specify text to find.

If you just want to search text or filename, leave one of input boxes empty. After your search command, it would return a list of files.

And all the upload and download files are in their own folder which in Debug.

When you got file list, you could double click one of them to start download.